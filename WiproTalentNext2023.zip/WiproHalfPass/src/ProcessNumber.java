import java.util.*;
public class ProcessNumber {
   public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	ProcessNumber p=new ProcessNumber();
	int n=sc.nextInt();
	int m=sc.nextInt();
	int ret=p.processNumber(n,m);
	System.out.println(ret);
}

public int processNumber(int input1, int input2) {
	List<Integer> li=new ArrayList<>();
	List<Integer> lk=new ArrayList<>();
	
	
	return 0;
}
}
