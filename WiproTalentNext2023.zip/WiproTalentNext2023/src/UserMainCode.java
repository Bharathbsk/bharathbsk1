import java.util.*;
import java.io.*;
class UserMainCode {

	public String cipherText(String input1) {
		String ans="";
		String word[]=input1.split(" ");
		int N=word.length;
		for(int i=0;i<word.length;i++) {
			String rev=new StringBuilder(word[i]).reverse().toString();
			int L=rev.length();
			String rep="";
			for(int j=0;j<L;j++) {
				char ch=rev.charAt(j);
				if(j!=0&&j%2==0) {
					if(ch>='A'&&ch<'Z') {
						int k=((ch+L)>90)?90:(ch+L);
						rep=rep+(char)k;
					}else {
						int k=((ch+L)>122)?122:(ch+L);
						rep=rep+(char)k;
					}
				}else 
					rep=rep+ch;
			}
			String tog="";
			int len=N-1;
		   for(int j=0;j<rep.length();j++) {
			   char cc=rep.charAt(j);
			   if(j==len) {         
				  cc=Character.isUpperCase(cc)?Character.toLowerCase(cc):Character.toUpperCase(cc); 
				  len=len+N;
				  tog=tog+cc;
			   }else
				   tog=tog+cc;
		   }
		   ans=ans+tog+" ";
		}
		return ans;
	}

  

}
















//public int findPIN(int input1, int input2, int input3, int input4) {
//    int arr[]= {input1,input2,input3};
//    int ev=0,od=0;
//    for(int i=0;i<arr.length;i++) {
//   	 String s=arr[i]+"";
//   	 for(int j=0;j<s.length();j++) {
//   		 char ch=s.charAt(j);
//   		if(j%2==0) { 
//   			ev=ev+Integer.parseInt(""+ch);
//   		}else {
//   			od=od+Integer.parseInt(""+ch);
//   		}
//   	 }
//    }
//    if(input4%2==0)
//   	return ev-od; 
//    else
//      return od-ev;
//   }







//public int firstRepeated(int[] input1, int input2) {
//	//write a logic
//	List<Integer> li=new ArrayList<>();
//	for(int i=input2-1;i>=0;i--) {
//		if(li.contains(input1[i])) {
//			return input1[i];
//		}else if(input1[i]>0) {
//			li.add(input1[i]);
//		}
//	}
//	if(li.size()>0)
//		return input1[input2-1];
//	return 0;
//}



//public int findPIN(int input1, int input2, int input3, int input4) {
//    int arr[]= {input1,input2,input3};
//    int ans=1;
//    for(int i=0;i<arr.length;i++) {
//    	List<Integer> li=new ArrayList<>();
//    	int num=arr[i];
//    	while(num>0) {
//    		li.add(num%10);
//    		num=num/10;
//    	}
//    	if(i%2==0)
//    		ans=ans*Collections.min(li);
//    	else
//    		ans=ans*Collections.max(li);
//    	
//    }
//	return ans-input4;
//}