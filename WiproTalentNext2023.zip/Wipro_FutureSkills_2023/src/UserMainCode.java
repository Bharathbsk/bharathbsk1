import java.util.*;
import java.util.regex.*;
public class UserMainCode {
	
	public String findStringVowelFirstAndLast(int input1, String[] input2) {
		String ans="";
		for(int i=0;i<input1;i++) {
			String s=input2[i].toLowerCase();
			if(s.length()>=1) {
			char c1=s.charAt(0);
			char c2=s.charAt(s.length()-1);
			if((c1=='a'||c1=='e'||c1=='i'||c1=='o'||c1=='u')&&
					(c2=='a'||c2=='e'||c2=='i'||c2=='o'||c2=='u')) {
				ans=ans+s;
			}
			}
		}
		if(ans=="")
			return "no matches found";
		return ans;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	public int find_tvalue(int input1, int input2, int input3) {
		int t=0;
		if(input2%2==0&&isPrime(input2)) {
			t=input1*input1*sumOfPrime(input2);
		}else if(input2%2!=0&&isPrime(input2)) {
			t=input2*input2*sumOfPrime(input3);
		}else if(input2%2==0) {
			t=input3*input3*sumOfPrime(input2+input3);
		}else {
			t=sumOfPrime(input1+input2+input3);
		}
		
		if(isPrime(t))
			return t+input3;
		else
		    return t-input3;
	   }
	   int sumOfPrime(int input2) {
		int sum=0;
		int c=0;
		int num=2;
		while(c<input2) {
			if(isPrime(num)) {
				sum=sum+num;
				c++;
			}
			num++;
		}
		return sum;
	   }
	   boolean isPrime(int input2) {
		 if(input2<2)return false;
		 for(int i=2;i<=input2/2;i++) {
			 if(input2%i==0)
				 return false;
		 }
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

















	public String emailIdCheck(String input1) {
		String w[]=input1.split("@");
		String s=w[1];
		String s2="",s3="";
	    int k=0;
	    for(int i=0;i<s.length();i++) {
	    	char ch=s.charAt(i);
	    	if(ch=='.') k=1;
	    	if(k==0)
	    		s2=s2+ch;
	    	else
	    		s3=s3+ch;
	    }
		if(w[0].length()>15) return "part 1 length is exceeding 15.";
		if(Pattern.matches("^[a-z0-9]{1,15}@(wipro||gmail||yahoo)\\.com$", input1))
			return w[0]+":"+s3+":valid";
		else
			return w[0]+":@"+s2+":invalid";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public int findTotalOccurrence(int input1, int input2) {
		int count=0;
		for(int i=0;i<=input2;i++) {
			int n=i;
			while(n>0) {
				int d=n%10;
				if(d==input1)
					count++;
				n/=10;
			}
		}
		return count;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public int findAverageRoundOff(int[] input1, int input2) {
		double sum=0;
		for(int i=0;i<input2;i++) {
			sum=sum+input1[i];
		}
		double avg=sum/input2;
		String s=Double.toString(avg);
		int d=s.indexOf('.')+1;
		if(Integer.parseInt(""+s.charAt(d))<=5)
			return (int)avg;
		return (int)Math.round(avg);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public int FindPosition(int input1) {
		//write your logic
		if(input1==0) return 1;
		if(input1==1) return 2;
		int f1=2;
		int f2=1;
		int count=3;
		while(f1<=input1) {
			count++;
			int t=f1;
			f1=f1+f2;
			f2=t;
		}
		return count;
	}
	































	




















	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

    
}
