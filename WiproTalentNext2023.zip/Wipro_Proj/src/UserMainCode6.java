import java.util.Scanner;
public class UserMainCode6 {
     public static void main(String[] args) {
    	 UserMainCode6 u=new UserMainCode6();
    	 Scanner sc=new Scanner(System.in);
    	 String input1=sc.next();
    	 String ret=u.formTheWord(input1);
    	 System.out.println(ret);
}  

	public String formTheWord(String input1) {//ww:ii:pp:rr:oo//WIPRO
		String arr[]=input1.split(":");//{ww,ii,pp,rr,oo}
		String r="";
		for(int i=0;i<arr.length;i++) {
			if(arr[i].charAt(0)==arr[i].charAt(1)) {
				r=r+arr[i].charAt(0);
			}else {
				int k=(char)arr[i].charAt(0)-(char)arr[i].charAt(1);
				r=r+(char)(64+k);
			}
		}
		String ret=r.toUpperCase();
		return ret;
	}
}
