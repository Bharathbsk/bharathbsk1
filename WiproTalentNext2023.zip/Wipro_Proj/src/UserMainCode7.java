import java.util.*;
public class UserMainCode7 {
     public static void main(String[] args) {
    	 UserMainCode7 u=new UserMainCode7();
    	 Scanner sc=new Scanner(System.in);
    	 String input1="abc";
    	 String input2="de";
    	 String ret=u.stringConcatention(input1,input2);
    	 System.out.println(ret);
}

	public String stringConcatention(String input1, String input2) {
		if(input1==null||input2==null||input1.isEmpty()||input2.isEmpty()) {
			return "null";
		}
		Set<Character> cc=new TreeSet<>();
		for(int i=0;i<input1.length();i++) {
			char ch=input1.charAt(i);
				if(ch!=' ') {
					cc.add(ch);
				}
		}
		for(int i=0;i<input2.length();i++) {
			char ch=input2.charAt(i);
				if(ch!=' ') {
					cc.add(ch);
				}
		}
		String ret="";
		for(Character c:cc) {
			ret=c+ret;
		}
		return ret;
	}
}