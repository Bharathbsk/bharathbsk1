import java.util.*;
public class UserMainCode8 {
     public static void main(String[] args) {
    	 UserMainCode8 u=new UserMainCode8();
    	 Scanner sc=new Scanner(System.in);
    	 int input1=sc.nextInt();
    	 int input2=sc.nextInt();
    	 int input3=sc.nextInt();
    	 int ret=u.findKey(input1,input2,input3);
    	 System.out.println(ret);
}

	public int findKey(int input1, int input2, int input3) {//3456
		int a=(input1/1000)%10;
		int b=(input2/100)%10;
		List<Integer> l3=new LinkedList<Integer>();
		l3.add((input3)%10);
		l3.add((input3/10)%10);
		l3.add((input3/100)%10);
		l3.add((input3/1000)%10);
		int c=Collections.max(l3);
		return (a*b)-c;
	}
}
