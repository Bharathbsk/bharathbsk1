import java.util.*;
public class UserMainCode2 {
     public static void main(String[] args) {
		UserMainCode2 u=new UserMainCode2();
		Scanner sc=new Scanner(System.in);
		int input1=sc.nextInt();
		int r=u.countPrimeDigit(input1);
		System.out.println(r);
	}

	public int countPrimeDigit(int input1) { 
	   int count=0;
		   while(input1>0) {
			   int r=input1%10;
			   if(prime(r)) {
				   count++;
			   }
			   input1=input1/10;
		   }
		return count;
	}
	private boolean prime(int input1) {
		if(input1>1) {
			int count=0;
			for(int i=2;i<=input1/2;i++) {
				if(input1%i==0) { 
					count++;
					break;
				}
			}
			if(count==0) {
				return true;
			}else {
				return false;
			}
		}else {
			return false;
		}
	}
}
