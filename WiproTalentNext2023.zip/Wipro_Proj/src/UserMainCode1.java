import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class UserMainCode1 {
     public static void main(String[] args) {
		UserMainCode1 u=new UserMainCode1();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int input2[]=new int[n];
		for(int i=0;i<n;i++) {
			input2[i]=sc.nextInt();
		}
		int input3[]=new int[n];
		for(int i=0;i<n;i++) {
			input3[i]=sc.nextInt();
		}
		int ret=u.magicstick(n,input2,input3);
		System.out.println(ret);
	}

	public int magicstick(int input1, int[] input2, int[] input3) {
		int ret=1000;
		for(int i=0;i<input1;i++) {
		  int sum=((input1-2)*(input3[i]))+((input1-3)*(input3[i]));
		  if(ret>sum) {
			  ret=sum;
		  }
		}
		return ret;
	}

	}
