import java.util.*;
public class UserMainCode4 {
     public static void main(String[] args) {
    	 UserMainCode4 u=new UserMainCode4();
    	 Scanner sc=new Scanner(System.in);
    	 int input2=sc.nextInt();
    	 int input1[]=new int[input2];
    	 for(int i=0;i<input2;i++) {
    		 input1[i]=sc.nextInt();
    	 }
    	 int ret=u.PositionBasedSum(input1,input2);
    	 System.out.println(ret);
}

	public int PositionBasedSum(int[] input1, int input2) {//4321  arr[]={31,34,234,3456}
		int sum=0;
		int n[]=new int[input2];
		int rr=1;
		for(int i=0;i<input2;i++) {
			int k=(input1[i]/rr)%10;
			n[i]=k;
			rr=rr*10;
		}
		for(int i=0;i<input2;i++) {
			sum=sum+(n[i]*n[i]);
		}	
		return sum;
	}
}