import java.util.Scanner;
public class UserMainCode5 {
     public static void main(String[] args) {
    	 UserMainCode5 u=new UserMainCode5();
    	 Scanner sc=new Scanner(System.in);
    	 int input1=sc.nextInt();
    	 String input2[]=new String[input1];
    	 for(int i=0;i<input1;i++) {
    		 input2[i]=sc.next();
    	 }
    	 String ret=u.findStringVowelFirstAndLast(input1,input2);
    	 System.out.println(ret);
}

	public String findStringVowelFirstAndLast(int input1, String[] input2) {
		String ret="";
		for(int i=0;i<input1;i++) {
			String k=input2[i].toLowerCase();
			char f=k.charAt(0);
			char l=k.charAt(input2[i].length()-1);
			if((f=='a'||f=='e'||f=='i'||f=='o'||f=='u')&&(l=='a'||l=='e'||l=='i'||l=='o'||l=='u')) {
				ret=ret+input2[i];
			}
		}
		if(ret.isEmpty()||ret==null) {
			return "no matches found";
		}
		
		
		return ret;
	}
}